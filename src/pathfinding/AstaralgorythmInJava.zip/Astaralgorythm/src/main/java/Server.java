import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;

public class Server extends Thread {
  // the version of the server
  public static final String VERSION = "V0";
  // the port that the server is conected to
  private static final int PORT = 1337;
  // the socket that the server uses for its one conection
  private static DatagramSocket socket;
  // the bytes that the server uses
  private byte[] buf = new byte[60000];

  /**
   * creates and runs a server that waits for an array maze and responds with the fastes way throug the array.
   * @param args
   */
  public static void main(String[] args) {
    Server server = new Server();
    try {
      socket = new DatagramSocket(PORT);
    } catch (SocketException e) {
      e.printStackTrace();
    }
    server.run();
  }

  /**
   * the running function for the server, it runs and waits for an maze in the form of an array, the maze packet
   * also needs to have an start point and a goal or else the maze wont work
   */
  public void run() {
    Astar astar = new Astar();
    while (true) {
      try {
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);
        System.out.println(packet.getLength());
        String recived = new String(packet.getData(), 0, packet.getLength());
        JSONObject jsonObject = new JSONObject(recived);
        System.out.println(jsonObject.toString());
        JSONArray maze = (((JSONArray) jsonObject.get("maze")));
        JSONArray start = ((JSONArray) jsonObject.get("start"));
        int[] decodedstart = new int[]{(Integer) start.get(0), (Integer) start.get(1)};
        JSONArray goal = ((JSONArray) jsonObject.get("goal"));
        int[] decodedgoal = new int[]{(Integer) goal.get(0), (Integer) goal.get(1)};
        int[][] decodedMaze = changeJSONArrayToInt(maze);
        ArrayList<int[]> path = astar.AstarAlgh(decodedMaze, decodedstart, decodedgoal);
        String sendArray;
        if (path == null) {
          sendArray = "no path";
        } else {
           sendArray = new JSONArray(path).toString();
        }
        System.out.println(sendArray);
        packet.setData(sendArray.getBytes());
        socket.send(packet);
        if (path != null){
        System.out.println("packet sent, path length was:  " + path.size());}
        else{
          System.out.println("packet sent, there was no path");
        }
      } catch (IOException e) {
        System.out.println(e.getMessage());
        socket.close();
        break;

      }
    }
  }

  /**
   * changes a json array consisting of integers in a two dimentional array into an two dimentional integer array
   *
   * @param jsonArray the json array to change.
   * @return the new integer array.
   */
  private int[][] changeJSONArrayToInt(JSONArray jsonArray) {
    int[][] decodedArray = new int[jsonArray.length()][((JSONArray) jsonArray.get(0)).length()];
    int x = 0;
    for (Object i : jsonArray) {
      String o = i.toString();
      o = o.replace("[", "");
      o = o.replace("]", "");
      String[] b = o.split(",");
      int y = 0;
      for (String k : b) {
        decodedArray[y][x] = Integer.parseInt(k);
        y++;
      }
      x++;
    }
    return decodedArray;
  }
}


