import java.io.IOException;
import java.net.*;

public class JSONParrser{
  private static Socket client;
  byte[] receiveData = new byte[1024];
  byte[] sendData = new byte[1024];
  DatagramSocket datagramSocket;

  public JSONParrser(Socket client) {
    try {
      this.client = client;
      datagramSocket = new DatagramSocket(1337);
      receiveData = new byte[1024];
      sendData = new byte[1024];
    } catch (SocketException e) {
      System.out.println("socket error: " + e.getMessage());
    }
  }

  public void run() {
    try {
      DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
      datagramSocket.receive(receivePacket);
      String sentence = new String(receivePacket.getData());
      System.out.println("RECEIVED: " + sentence);
      InetAddress IPAddress = receivePacket.getAddress();
      int port = receivePacket.getPort();
      String capitalizedSentence = sentence.toUpperCase();
      sendData = capitalizedSentence.getBytes();
      DatagramPacket sendPacket =
          new DatagramPacket(sendData, sendData.length, IPAddress, port);
      datagramSocket.send(sendPacket);
    } catch (IOException e) {
      System.out.println("IO error: " + e.getMessage());
    }
  }
}
