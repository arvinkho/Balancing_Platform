import java.util.*;

/**
 * an class that can preforme the pathfinding algorythim : A* (a star) it pre creates some of the memory heavy prosesses
 * to save time when it's called.
 * @author fredborg
 * @version 1.1
 */
class Astar {
  // an open set contining all points that we have a path to but have not yet vissited.
  private static final HashMap<int[], Node> openSet = new HashMap<>();
  // cloased set containing all points that we have visited.
  private static final HashSet<Node> closedSet = new HashSet<>();
  // the maze created of Nodes we wil convert anny maze given to us into this maze.
  private static Node[][] maze;
  // the goal we want to reach
  private static int[] goal;
  // the dimentions of the maze
  private int row;
  private int col;

  /**
   * the constructior for Astar. in adition to creating the normal variables we will be using it
   * creates all the nodes and puts them into an array.
   */
  public Astar() {
    int rowNumb = 0;
    maze = new Node[100][100];
    row = maze.length - 1;
    col = maze[0].length - 1;
    for (Node[] rows : maze) {
      for (int colNumb = 0; colNumb < rows.length; colNumb++) {
        maze[rowNumb][colNumb] = new Node(new int[]{rowNumb, colNumb}, null, row, col);
        System.out.println(rowNumb + " : " + colNumb);
      }
      rowNumb++;
    }
  }

  /**
   * retruns the path we traveled to get to this point.
   * @param node the  node that we have reached and want to get the path from.
   * @return the finnised path.
   */
  private static ArrayList<int[]> findPath(Node node) {
    ArrayList<int[]> path = new ArrayList<>();
    System.out.println(34);
    while (node != null) {
      path.add(node.getPOS());
      if (node != node.getParent()) {
        node = node.getParent();
      }
    }
    return path;
  }
  /**
   * clears the open and closed set.
   */
  private void resetLists() {
    openSet.clear();
    closedSet.clear();
  }

  /**
   * resets all the nodes in the matrix
   * @param matrix the matrix that we want to reset.
   */
  private void resetMaze(int[][] matrix) {
    int rowNumb = 0;
    Node node;
    for (int[] rows : matrix) {
      for (int colNumb = 0; colNumb < rows.length; colNumb++) {
        node = maze[rowNumb][colNumb];
        if (rows[colNumb] == 1) {
          node.setWall(true);
        } else {
          node.setWall(false);
        }
        node.reset(goal);
      }
      rowNumb++;
    }
  }

  /**
   * when given a 2d matrix of points that are either one or zero it returnes the most effective path from start
   * to goal. where ones are considered walls and you can only travel on zeroes.
   * @param newMaze
   * @param start
   * @param newgoal
   * @return
   */
  public ArrayList<int[]> AstarAlgh(int[][] newMaze, int[] start, int[] newgoal) {

    goal = newgoal;
    resetLists();
    resetMaze(newMaze);

    Node startNode = maze[start[0]][start[1]];
    startNode.setgScore(0);
    startNode.sethScore(1000000000);

    Node endNode = maze[goal[0]][goal[1]];
    endNode.setgScore(1000000000);
    endNode.sethScore(0);

    openSet.put(startNode.getPOS(), startNode);
    while (!openSet.isEmpty()) {
      Node current = getBestNode(openSet);
      if (Arrays.equals(current.getPOS(), goal)) {
        System.out.println("found path");

        ArrayList<int[]> path = findPath(endNode);
        path = reducePath(path);

        return path;
      }
      openSet.remove(current.getPOS(), current);
      closedSet.add(current);
      HashSet<int[]> nabours = current.getNabours();
      nabours.forEach(nabour -> lookAtNabour(current, nabour));

    }
    System.out.println("no path");
    return null;
  }

  /**
   * when given a set of 2d points it returns all points that are on a edge of strait lines created by the points given.
   * @param path the point that are to be reduced.
   * @return an Arraylist of points that are reduced.
   */
  private ArrayList<int[]> reducePath(ArrayList<int[]> path) {
    if (path == null){
      return null;
    }
    //creating vaiables
    ArrayList<int[]> returnPath = new ArrayList<>();
    // add the end point.
    returnPath.add(path.get(0));
    int[] lastPoint = path.get(0);
    int[] firstLinePoint = path.get(0);
    // checking if the area of the triangle created by the first point in this line the previous point
    // checked and the current point is zero
    // if it is then the 3 points are on a line and we should not add the point to our reduced set
    for (int[] point : path) {
      int area = point[0] * (lastPoint[1] - firstLinePoint[1])
          + lastPoint[0] * (firstLinePoint[1] - point[1])
          + firstLinePoint[0] * (point[1] - lastPoint[1]);
      if (area != 0) {
        firstLinePoint = lastPoint;
        returnPath.add(lastPoint);
      }
      lastPoint = point;
    }
    // adds the start point before we return it.
    returnPath.add(path.get(path.size()-1));
    return returnPath;
  }

  /**
   * looks at a node and determines if it is:
   *  in the closed set.
   *  has a better path to it in the open set.
   * if both of those are false the node is added to the open set and the path is changed to the current path.
   * @param current the node that we are currently at.
   * @param newnaobur the posistion of the node we are checking.
   */
  private void lookAtNabour(Node current, int[] newnaobur) {
    int[] currentPos = current.getPOS();
    int[] newPos = new int[]{currentPos[0] + newnaobur[0], currentPos[1] + newnaobur[1]};
    Node nabour = maze[newPos[0]][newPos[1]];
    if (!nabour.isWall()) {
      if (!closedSet.contains(nabour)) {
        double tempGscore = current.getgScore() + getPytagorian(newnaobur[0], newnaobur[1]);
        if (!(openSet.getOrDefault(nabour.getPOS(), maze[goal[0]][goal[1]]).getgScore() <= tempGscore)) {
          nabour.setgScore(tempGscore);
          nabour.sethScore(getPytagorian(
              (goal[0] - newPos[0]),
              (goal[1] - newPos[0])));
          nabour.setParent(current);
          openSet.put(nabour.getPOS(), nabour);
        }
      }
    }
  }

  /**
   * sorts troug the open set and returns the best posible node from this set.
   * @return the best node in the open set
   */
  private Node getBestNode(HashMap<int[],Node> set) {
    Iterator<Node> it = set.values().iterator();
    Node bestNode = it.next();
    Node node;
    while (it.hasNext()) {
      node = it.next();
      if (node.getfScore() < bestNode.getfScore()) {
        bestNode = node;
      }
    }
    return bestNode;
  }

  /**
   * preformes the pythagorian theorem on two values and returns the result
   * @return the sresult of the bythagoina theorem between these points
   */

  private double getPytagorian(int a, int b) {
    return Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
  }
}
