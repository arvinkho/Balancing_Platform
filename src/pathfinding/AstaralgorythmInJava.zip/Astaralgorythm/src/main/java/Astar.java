import java.util.*;

class Astar {
  // an open set
  private static final HashMap<int[], Node> openSet = new HashMap<>();
  // cloased set
  private static final HashSet<Node> closedSet = new HashSet<>();
  // a maze
  private static Node[][] maze;
  // the goal
  private static int[] goal;
  private int row;
  private int col;

  public Astar() {
    int rowNumb = 0;
    maze = new Node[100][100];
    row = maze.length - 1;
    col = maze[0].length - 1;
    for (Node[] rows : maze) {
      for (int colNumb = 0; colNumb < rows.length; colNumb++) {
        maze[rowNumb][colNumb] = new Node(new int[]{rowNumb, colNumb}, null, row, col);
        System.out.println(rowNumb + " : " + colNumb);
      }
      rowNumb++;
    }
  }

  private static ArrayList<int[]> findPath(Node node) {
    ArrayList<int[]> path = new ArrayList<>();
    System.out.println(34);
    while (node != null) {
      path.add(node.getPOS());
      node = node.getParent();
    }
    return path;
  }

  private void resetLists() {
    openSet.clear();
    closedSet.clear();
  }

  private void resetMaze(int[][] newMaze) {
    int rowNumb = 0;
    Node node;
    for (int[] rows : newMaze) {
      for (int colNumb = 0; colNumb < rows.length; colNumb++) {
        node = maze[rowNumb][colNumb];
        if (rows[colNumb] == 1) {
          node.setWall(true);
        } else {
          node.setWall(false);
        }
        node.reset(goal);
      }
      rowNumb++;
    }
  }

  public ArrayList<int[]> AstarAlgh(int[][] newMaze, int[] start, int[] newgoal) {

    goal = newgoal;
    resetLists();
    resetMaze(newMaze);

    Node startNode = maze[start[0]][start[1]];
    startNode.setgScore(0);
    startNode.sethScore(1000000000);

    Node endNode = maze[goal[0]][goal[1]];
    endNode.setgScore(1000000000);
    endNode.sethScore(0);

    openSet.put(startNode.getPOS(), startNode);
    while (!openSet.isEmpty()) {
      Node current = getBestNode();
      if (Arrays.equals(current.getPOS(), goal)) {
        System.out.println("found path");
        return findPath(endNode);
      }
      openSet.remove(current.getPOS(), current);
      closedSet.add(current);
      HashSet<int[]> nabours = current.getNabours();
      nabours.forEach(nabour -> lookAtNabour(current, nabour));

    }
    System.out.println("no path");
    return null;
  }

  private void lookAtNabour(Node current, int[] newnaobur) {
    int[] currentPos = current.getPOS();
    int[] newPos = new int[]{currentPos[0] + newnaobur[0], currentPos[1] + newnaobur[1]};
    Node nabour = maze[newPos[0]][newPos[1]];
    if (!nabour.isWall()) {
      if (!closedSet.contains(nabour)) {
        double tempGscore = current.getgScore() + getTrigValue(newnaobur[0], newnaobur[1]);
        if (!(openSet.getOrDefault(nabour.getPOS(), maze[goal[0]][goal[1]]).getgScore() <= tempGscore)) {
//        if (openSet.containsValue(nabour)) {
//          if (openSet.get(nabour.getPOS()).getgScore() <= tempGscore) {
//            return;
//          }
//        }
          nabour.setgScore(tempGscore);
          nabour.sethScore(getTrigValue(
              (goal[0] - newPos[0]),
              (goal[1] - newPos[0])));
          nabour.setParent(current);
          openSet.put(nabour.getPOS(), nabour);
        }
      }
    }
  }

  private Node getBestNode() {
    Iterator<Node> it = openSet.values().iterator();
    Node bestNode = it.next();
    Node node;
    while (it.hasNext()) {
      node = it.next();
      if (node.getfScore() < bestNode.getfScore()) {
        bestNode = node;
      }
    }
    return bestNode;
  }

  private double getTrigValue(int a, int b) {
    return Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
  }
}
