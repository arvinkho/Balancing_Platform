import java.util.HashSet;

public class Node {
  private final int[] POS;
  private Node parent;
  private final int rows;
  private final int cols;
  private final HashSet<int[]> nabours = new HashSet<>();
  private double gScore;
  private double hScore;
  private double fScore;
  private boolean wall;

  public Node(int[] pos, Node parent, int rows, int cols) {
    this.POS = pos;
    this.parent = parent;
    this.rows = rows;
    this.cols = cols;
    generateNabours();
  }

  public int[] getPOS() {
    return POS;
  }

  public Node getParent() {
    return parent;
  }

  public void setParent(Node parent) {
    this.parent = parent;
  }


  public HashSet<int[]> getNabours() {
    return nabours;
  }


  public double getgScore() {
    return gScore;
  }

  public void setgScore(double gScore) {
    this.gScore = gScore;
    recalcF();
  }


  public void sethScore(double hScore) {
    this.hScore = hScore;
    recalcF();
  }

  public double getfScore() {
    return fScore;
  }

  public boolean isWall() {
    return this.wall;
  }

  private void generateNabours() {
    this.nabours.clear();
    if (POS[0] > 0) {
      this.nabours.add(new int[]{-1, 0});
      if (POS[1] > 0) {
        this.nabours.add(new int[]{-1, -1});
      }
      if (POS[1] < rows) {
        this.nabours.add(new int[]{-1, 1});
      }
    }
    if (POS[0] < cols) {
      this.nabours.add(new int[]{1, 0});
      if (POS[1] > 0) {
        this.nabours.add(new int[]{1, -1});
      }
      if (POS[1] < rows) {
        this.nabours.add(new int[]{1, 1});
      }
    }
    if (POS[1] > 0) {
      this.nabours.add(new int[]{0, -1});
    }
    if (POS[1] < rows) {
      this.nabours.add(new int[]{0, 1});
    }
  }
  public void setWall(boolean wall){
    this.wall = wall;
  }
public void reset(int[] goal){
    this.gScore = 0;
    this.hScore = Math.sqrt(Math.pow((goal[0] - getPOS()[0]), 2) + Math.pow(goal[1] - getPOS()[0], 2));
    this.fScore = 0;
}
  private void recalcF() {
    this.fScore = gScore + hScore;
  }
}
