import java.util.HashSet;

/**
 * a node that holds a position and a score for the distance form the last and first point to this point in the maze.
 * it also has a parrent: an other node that we reached this node troug and a set of nodes that can be reached
 * troug this node.
 * in adition it has a wall atribute, if true we cannot travel troug this node.
 * @author fredborg
 * @version 1
 */
public class Node {
  // the position this node holds in the maze
  private final int[] POS;
  // the node we was in before we reached this node
  private Node parent;
  // the dimentions of the maze(used to calculate the nabours
  private final int rows;
  private final int cols;
  // the nodes that can be reached troug this node.
  private final HashSet<int[]> nabours = new HashSet<>();
  // the distance of the path traveld to get to this node
  private double gScore;
  // the estimated huristic cost of the path to get to the final node.
  private double hScore;
  // the sum of the g and h score.
  private double fScore;
  // if this node is a wall we cant travle troug it.
  private boolean wall;

  /**
   * creates a node
   */
  public Node(int[] pos, Node parent, int rows, int cols) {
    this.POS = pos;
    this.parent = parent;
    this.rows = rows;
    this.cols = cols;
    generateNabours();
  }

  /**
   * @return the position of this node
   */
  public int[] getPOS() {
    return POS;
  }

  /**
   *
   * @return the parent of this node
   */
  public Node getParent() {
    return parent;
  }

  /**
   * changes the parent of this node
   * @param parent the new parent
   */
  public void setParent(Node parent) {
    this.parent = parent;
  }

  /**
   *
   * @return the positions of all the nabours of this node
   */
  public HashSet<int[]> getNabours() {
    return nabours;
  }

  /**
   *
   * @return the g score of this node
   */
  public double getgScore() {
    return gScore;
  }

  /**
   * changes the g score and recalculates the f score after the new g score is set
   * @param gScore the new g score
   */
  public void setgScore(double gScore) {
    this.gScore = gScore;
    recalcF();
  }

  /**
   * changes the h score and recalculates the f score after the new h score is set
   * @param hScore the new ghscore
   */
  public void sethScore(double hScore) {
    this.hScore = hScore;
    recalcF();
  }

  /**
   *
   * @return the f score of this node
   */
  public double getfScore() {
    return fScore;
  }

  /**
   *
   * @return true if this node is a wall, false othervice.
   */
  public boolean isWall() {
    return this.wall;
  }

  /**
   * generates a set of nabours, chacks that it does not create a noabour that is outside the matrix dimentions.
   */
  private void generateNabours() {
    this.nabours.clear();
    if (POS[0] > 0) {
      this.nabours.add(new int[]{-1, 0});
      if (POS[1] > 0) {
        this.nabours.add(new int[]{-1, -1});
      }
      if (POS[1] < rows) {
        this.nabours.add(new int[]{-1, 1});
      }
    }
    if (POS[0] < cols) {
      this.nabours.add(new int[]{1, 0});
      if (POS[1] > 0) {
        this.nabours.add(new int[]{1, -1});
      }
      if (POS[1] < rows) {
        this.nabours.add(new int[]{1, 1});
      }
    }
    if (POS[1] > 0) {
      this.nabours.add(new int[]{0, -1});
    }
    if (POS[1] < rows) {
      this.nabours.add(new int[]{0, 1});
    }
  }

  /**
   * sets this node to a wall or to an open path.
   * @param wall the new condition of this node
   */
  public void setWall(boolean wall){
    this.wall = wall;
  }

  /**
   * resets and recalculates the huristic scores of this node in adition to resetting the parrent of this node
   * @param goal the new goal to reach
   */
  public void reset(int[] goal){
    this.gScore = 0;
    this.hScore = Math.sqrt(Math.pow((goal[0] - getPOS()[0]), 2) + Math.pow(goal[1] - getPOS()[0], 2));
    this.fScore = 0;
    this.parent = null;
}

  /**
   * recalcutaltes the f score.
   */
  private void recalcF() {
    this.fScore = gScore + hScore;
  }
}
